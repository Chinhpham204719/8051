#include <mcs51/8052.h>

#define k1 P3_3 //tang timer
#define k2 P3_4 //giam timer
#define k3 P3_2 //bat dau timer

#define Q4 P2_0
#define Q3 P2_1
#define Q2 P2_2
#define Q1 P2_3

#define Beep P3_6//coi bao dong
#define led P1_0

unsigned int Timer_running = 0;
unsigned char Time;
typedef unsigned int u16;
typedef unsigned char u8;

u8 i, min = 0, sec = 0;
u8 __code LED_Mask[10]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};

//Ham tao tre
void delay(u16 i)
{
	while(i--);
}

//Khoi tao
void Init()
{
	TMOD = 0x01;
    TH0 = 0x4C;	 //~50 ms
    TL0 = 0x00;
    EA = 1;
    ET0 = 1;
    TR0 = 1;
}

//Ham hien thi phut:
void Display_min(u8 min){
    //Hien thi so phut hang chuc
    Q1 = 1;
    Q2 = 1;
    Q3 = 1;
    Q4 = 0;

    P1 = LED_Mask[min/10]; //So phut hang chuc hien tai
    delay(100);
    P1=0xFF; //Tat LED
    delay(100);

    //Hien thi so phut hang don vi
    Q4 = 1;
    Q3 = 0;

    P1 = LED_Mask[min%10]; //So phut hang don vi hien tai
    P1_7 = 0;   
    delay(100);
    P1=0xFF; //Tat LED
    delay(100);
}

//Ham hien thi giay:
void Display_sec(u8 sec){
    //Hien thi so giay hang don vi
    Q1 = 0;
    Q2 = 1;
    Q3 = 1;
    Q4 = 1;

    P1 = LED_Mask[sec%10]; //So giay hang don vi hien tai
    delay(100);
    P1=0xFF; //TatLED
    delay(100);

    //Hien thi so giay hang chuc 
    Q1 = 1;
    Q2 = 0;

    P1 = LED_Mask[sec/10];//So giay hang chuc hien tai
    delay(100);
    P1=0xFF; //Tat LED
    delay(100);
}

//Hien thi man hinh:
void Display()
{
    Display_min(min);
    Display_sec(sec);
}

void main()
{
	Init();
	while(1)
	{
	    Display();
	    //Tang timer:
        if (k1 == 0) {
            delay(20000);
            min++;
        }
        //Giam timer:
        if (k2 == 0 && min !=0) {
            delay(20000);
            min--;
        }
		//Bat dau timer:
        if (k3 == 0){
            Time = 0;
            Timer_running = 1;
        }
    
        if (Time == 20 && Timer_running == 1) //Chay xong 1s
            if(sec!=0)
                sec--; //Giam 1s
            else
                if (min == 0){
                    Timer_running = 0;
                    Beep = 0;       //Bat coi
                    Time = 0;       //RESET time

                    while (Time != 20); //Bam 1s
                    Beep = !Beep;   //Tat coi
                    Time = 0;       //RESET time

                    while (Time != 20); //Bam 1s
                    Beep = !Beep;   //Bat coi
                    Time = 0;       //RESET time

                    while (Time != 20); //Bam 1s
                    Beep = !Beep;   //Tat coi
                    Time = 0;       //RESET time

                    while (Time != 20); //Bam 1s
                    Beep = !Beep;   //Bat coi
                    Time = 0;       //RESET time

                    while (Time != 20); //Bam 1s
                    Beep = !Beep;   //Tat coi
                }
                else{
                    min --; //giam 1m
                    sec = 59; //dat 59s
                }

            Display();
            Time = 0;
        }
    }
}

//Ham xu ly ngat
void Timer0() __interrupt (1)
{
	  TH0 = 0x4C;	 //~50 ms
	  TL0 = 0x00;
	  Time++;
}
