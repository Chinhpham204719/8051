#include <mcs51/8052.h>
#include<math.h>
#include<string.h>
#define DQ	P3_7 //Du lieu cam bien nhiet DS18B20
#define LCD_DATA P2 //Du lieu LCD
#define EN P0_5
#define RS P0_7
#define RW P0_6
//Temp variables
unsigned char curr_temp;
unsigned char lowest_temp_each6s = 0 , hightest_temp_each6s = 0;//cap nhat moi lan doc nhiet do
unsigned char lowest_temp_each1m = 0 , hightest_temp_each1m = 0;//cap nhat moi 1p
unsigned char times_read_temp = 0;//so lan doc  nhiet do hien tai
unsigned char first_time = 0;//Lan dau doc nhiet do
//after update curr_temp 6 times => update lowest_temp , hightest_temp
unsigned char unit = 0;// convert unit C(0) <-> F(1)

void delay_ms(unsigned int t);//Ham tre dung timer0
void delay_us_DS18B20(unsigned int t);//Ham tre micro second

void Init_DS18B20();//Khoi tao DS18B20
unsigned char ReadByteFromScratchpad();//Doc 1 byte tu Scratchpad
void WriteByteToScratchpad(unsigned char byte);//Viet 1 byte vao Scratchpad
void ReadTemperature();//Doc cam bien DS18B20

void Init_System();//Khoi tao he thong
void Wait_For_LCD();//Doi LCD san sang
void LCD_Send_Command(unsigned char x);//send command to LCD
void LCD_Write_One_Char(unsigned char c);//Hien thi 1 ky tu
void LCD_Write_String(unsigned char *s);//Hien thi mot xau ky tu
void LCD_Gotoxy(unsigned char x, unsigned char y);//chuyen con tro LCD den (x,y)
void Show_Tem();// hien thi nhiet do tren LCD

unsigned char C_To_F(unsigned char c);
unsigned char F_To_C(unsigned char f);

//Ham tre dung timer0
void delay_ms(unsigned int s)
{
    unsigned int i = 0;
    for(i = 0 ; i < s; i++)
    {
        //~1ms
        TH0 = 0xFC;
        TL0 = 0x66; // 64614 => ~1ms with f_XTAL = 11. 0592MHz
        TF0 = 0;
        TR0 = 1;
        while(TF0 == 0);
    }

}

//Ham tre micro second
void delay_us_DS18B20(unsigned int t)
{
    while(t--);
}

//-------DS18B20----------
//Khoi tao DS18B20
void Init_DS18B20()
{
    DQ = 1;
    delay_us_DS18B20(8);
    DQ = 0;					//Dat lai xung
    delay_us_DS18B20(65); 	//thoi gian toi thieu
    DQ = 1;					
    delay_us_DS18B20(20);   //Doi DS18B20 tra loi
}

//Doc 1 byte tu Scratchpad
unsigned char ReadByteFromScratchpad()
{
    unsigned char i = 0;
    unsigned char byte = 0;
    for (i = 8; i > 0; i--){
          DQ = 0;
          byte >>= 1;
          DQ = 1;			//Day LED giai phong 1 bit
          if(DQ)			
          	byte |= 0x80;
          delay_us_DS18B20(4);
    }
    return(byte);
}

//Viet 1 byte vao Scratchpad
void WriteByteToScratchpad(unsigned char byte)
{
    unsigned char i = 0;
    for (i = 8; i > 0; i--){
        DQ = 0;
        DQ = byte&0x01;
        delay_us_DS18B20(5);
        DQ = 1;	  	//Giai phong 1 byte
        byte >>= 1;
    }
}

//Doc cam bien DS18B20
void ReadTemperature()
{
    unsigned char Byte0 = 0;		//Byte0 cua Scratchpad
    unsigned char Byte1 = 0;		//Byte1 cua Scratchpad

    Init_DS18B20();				   	//Khoi  tao DS18B20 
    WriteByteToScratchpad(0xCC);	//Lenh dung ROM [CCh] 
    WriteByteToScratchpad(0x44);	//Lenh chuyen doi T [44h] . To initiate a temp measurement and A-to-D conversion.
    delay_us_DS18B20(10);

    Init_DS18B20();					//Khoi tao DS18B20 
    WriteByteToScratchpad(0xCC);	//Lenh dung ROM [CCh] 
    WriteByteToScratchpad(0xBE);	//Doc gia tri nhiet do. Lenh doc Schratchpad [BEh] .
    delay_us_DS18B20(10);
    Byte0=ReadByteFromScratchpad();	//Doc Byte0 Scratchpad (byte thap cua nhiet do)
    Byte1=ReadByteFromScratchpad();	//Doc Byte1 Scratchpad (byte cao cua nhiet do)

	//Tinh gia tri nhiet do tu Byte0 & Byte1. Luu vao gia tri nhiet do voi don vi 'C
	curr_temp = ((Byte1*256+Byte0)>>4);
    //Voi do F 
    if(unit == 1)
    {
        curr_temp = C_To_F(curr_temp);

    }

	times_read_temp++;//so lan cap nhat curr_temp
	if(lowest_temp_each6s > curr_temp ) lowest_temp_each6s = curr_temp;
	if(hightest_temp_each6s < curr_temp) hightest_temp_each6s = curr_temp;

    //Lan dau
    if(first_time == 0)
    {
        lowest_temp_each1m = curr_temp;
        lowest_temp_each6s = curr_temp;
        hightest_temp_each1m = curr_temp;
        hightest_temp_each6s = curr_temp;
        first_time = 1;
    }

}

//-------LCD----------
//Khoi tao he thong
void Init_System()
{
    //Ngat
    TMOD = 0x01;//module 1 voi timer0
    EA = 1;
    EX0 = 1;//dung int0 de chuyen doi don vi nhiet do

    //LCD
	RW=1;//Write 

	unit = 0;


}

void LCD_init()
{
	LCD_Send_Command(0x38); //8 bit, 2 lines
	LCD_Send_Command(0x0C); //Bat man hinh, tat con tro
	LCD_Send_Command(0x01); //clear
	LCD_Send_Command(0x80); //tro ve ban dau
}

//Doi LCD san sang
void Wait_For_LCD()
{
	//Delay_By_Timer_0(80);
	delay_ms(1);
}

//send command to LCD
void LCD_Send_Command(unsigned char x)
{
	LCD_DATA=x;
	RS=0;
	RW=0;
	EN=1;
	delay_ms(1);
	EN=0;
	Wait_For_LCD();
	EN=1;
}

//Hien thi 1 ky tu
void LCD_Write_One_Char(unsigned char c)
{
	LCD_DATA=c;
	RS=1;
	RW=0;
	EN=1;
	delay_ms(1);
	EN=0;
	Wait_For_LCD();
	EN=1;
}

//Hien thi mot xau ky tu
void LCD_Write_String(unsigned char *s)
{
	unsigned char length;
	length=strlen(s);
	while(length!=0)
	{
		LCD_Write_One_Char(*s);
		s++;
		length--;
	}
}

//chuyen con tro LCD den (x,y)
void LCD_Gotoxy(unsigned char x, unsigned char y){
        unsigned char address;
        if(!y)address=(0x80+x);
        else address=(0xc0+x);
        delay_us_DS18B20(1000);
        LCD_Send_Command(address);
        delay_us_DS18B20(50);
}

// hien thi nhiet do tren LCD
void Show_Tem()
{
     LCD_Gotoxy(0,0);
     //cap nhat L and H
     if(times_read_temp == 10)//one minute
     {
         //cap nhat
         lowest_temp_each1m = lowest_temp_each6s;
         hightest_temp_each1m = hightest_temp_each6s;

         //reset
         times_read_temp = 0;
     }
     //dong 1
     LCD_Write_String("Cur Temp: ");
     LCD_Write_One_Char((curr_temp%100)/10+48);//hang chuc
     LCD_Write_One_Char((curr_temp%10)+48);//hang don vi
     if(unit == 0 )
     LCD_Write_String("'C");
     else LCD_Write_String("'F");

     //dong 2
     LCD_Send_Command(0xC0);//bat dau line2
     LCD_Write_String("L:");
     LCD_Write_One_Char((lowest_temp_each1m%100)/10+48);//hang chuc
     LCD_Write_One_Char((lowest_temp_each1m%10)+48);//hang don vi
     LCD_Write_String(" H:");
     LCD_Write_One_Char((hightest_temp_each1m%100)/10+48);//hang chuc
     LCD_Write_One_Char((hightest_temp_each1m%10)+48);//hang don vi
}

//doi don vi C -> F
unsigned char C_To_F(unsigned char c) {
    float f = (c * 9 / 5.0) + 32;
    return (unsigned char)(f + 0.5);
}

//doi don vi F -> C
unsigned char F_To_C(unsigned char f) {
    float c = (f - 32) * 5 / 9.0;
    return (unsigned char)(c + 0.5);
}

void ISR0() __interrupt (0)
{
	EA = 0;
	delay_ms(500);
	unit = 1- unit;
	if(unit == 1)
    {
        curr_temp = C_To_F(curr_temp);
        lowest_temp_each1m = C_To_F(lowest_temp_each1m);
        lowest_temp_each6s = C_To_F(lowest_temp_each6s);
        hightest_temp_each1m = C_To_F(hightest_temp_each1m);
        hightest_temp_each6s = C_To_F(hightest_temp_each6s);
        Show_Tem();
    }
    else
    {
        curr_temp = F_To_C(curr_temp);
        lowest_temp_each1m = F_To_C(lowest_temp_each1m);
        lowest_temp_each6s = F_To_C(lowest_temp_each6s);
        hightest_temp_each1m = F_To_C(hightest_temp_each1m);
        hightest_temp_each6s = F_To_C(hightest_temp_each6s);
        Show_Tem();
    }
	EA = 1;
}

void main()
{

    Init_System();
	LCD_init();
	LCD_Write_String("Taking temp...");//doi
    delay_ms(500);

    //doi cam bien ket noi
    while(1){
        ReadTemperature();
        if(curr_temp != 85) break;
    }
    times_read_temp = 0;
    first_time = 0 ;
    LCD_Send_Command(0x01);//clear
	while(1){
          LCD_Gotoxy(0,0);
		  ReadTemperature(); 	//Doc DS18B20 ...
		  Show_Tem();
		  delay_ms(6000);		//delay 6s
	}
}
